console.log("Welcome to the Community Portal");

window.onload = function () {
    alert("Page Loaded Successfully");
};

fetch("events.json")
.then(res => res.json())
.then(data => displayEvents(data));

const container = document.getElementById("eventContainer");

function displayEvents(events){

    container.innerHTML = "";

    events.forEach(event => {

        if(event.seats > 0){

            const card = document.createElement("div");
            card.className = "eventCard";

            card.innerHTML = `
                <h3>${event.name}</h3>
                <p>Category: ${event.category}</p>
                <p>Seats: ${event.seats}</p>
                <button onclick="register('${event.name}')">Register</button>
            `;

            container.appendChild(card);
        }
    });
}

function register(name){

    try{
        console.log(name + " registered");
        document.getElementById("message").innerText =
        name + " Registration Successful";
    }
    catch(err){
        console.log(err);
    }
}

document.getElementById("categoryFilter").onchange = function () {
    console.log(this.value);
};

document.getElementById("searchBox").addEventListener("keydown", function () {
    console.log("Searching...");
});

$("#registerBtn").click(function(){
    $("#message").fadeOut().fadeIn();
});