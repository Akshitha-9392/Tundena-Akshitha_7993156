import java.util.List;
import java.util.stream.Collectors;
record Person(String name, int age) {}

public class RecordDemo {

    public static void main(String[] args) {

        Person p1 = new Person("Akshitha", 20);
        Person p2 = new Person("Rahul", 17);
        Person p3 = new Person("Priya", 22);
        Person p4 = new Person("Kiran", 16);

        // Step 3: Print record objects
        System.out.println("All Persons:");
        System.out.println(p1);
        System.out.println(p2);
        System.out.println(p3);
        System.out.println(p4);
        List<Person> people = List.of(p1, p2, p3, p4);
        List<Person> adults = people.stream()
                .filter(p -> p.age() >= 18)
                .collect(Collectors.toList());
        System.out.println("\nAdults (age >= 18):");
        for (Person p : adults) {
            System.out.println(p.name() + " - " + p.age());
        }
    }
}