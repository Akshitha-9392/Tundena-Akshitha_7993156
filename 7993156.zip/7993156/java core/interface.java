interface Playable {
    void play();
}
class Guitar implements Playable {
    public void play() {
        System.out.println("Playing the Guitar 🎸");
    }
}

class Piano implements Playable {
    public void play() {
        System.out.println("Playing the Piano 🎹");
    }
}

public class InterfaceDemo {

    public static void main(String[] args) {
        Playable g = new Guitar();
        g.play();
        Playable p = new Piano();
        p.play();
    }
}