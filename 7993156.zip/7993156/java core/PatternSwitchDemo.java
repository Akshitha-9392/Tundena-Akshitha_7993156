public class PatternSwitchDemo {
    public static void checkType(Object obj) {
        switch (obj) {

            case Integer i ->
                System.out.println("It is an Integer: " + i);

            case String s ->
                System.out.println("It is a String: " + s);

            case Double d ->
                System.out.println("It is a Double: " + d);

            case Boolean b ->
                System.out.println("It is a Boolean: " + b);

            case null ->
                System.out.println("It is a null value");

            default ->
                System.out.println("Unknown type: " + obj.getClass().getSimpleName());
        }
    }

    public static void main(String[] args) {

        checkType(100);
        checkType("Hello Java");
        checkType(45.67);
        checkType(true);
        checkType(null);
        checkType('A');
    }
}