public class TypeCasting {

    public static void main(String[] args) {
        double decimalNumber = 45.78;
        int intValue = (int) decimalNumber;
        System.out.println("Double value: " + decimalNumber);
        System.out.println("Converted to int: " + intValue);

        int number = 25;
        double doubleValue = (double) number;
        System.out.println("Integer value: " + number);
        System.out.println("Converted to double: " + doubleValue);

    }
}
