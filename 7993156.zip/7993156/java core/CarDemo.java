class Car {
    String make;
    String model;
    int year;
    void displayDetails() {
        System.out.println("Car Details:");
        System.out.println("Make  : " + make);
        System.out.println("Model : " + model);
        System.out.println("Year  : " + year);
        System.out.println("----------------------");
    }
}

public class CarDemo {

    public static void main(String[] args) {
        Car car1 = new Car();
        car1.make = "Toyota";
        car1.model = "Innova";
        car1.year = 2020;
        car1.displayDetails();

        Car car2 = new Car();
        car2.make = "Honda";
        car2.model = "City";
        car2.year = 2022;
        car2.displayDetails();
    }
}