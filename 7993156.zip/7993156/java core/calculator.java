import java.util.Scanner;
public class calculator  {
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter num1: ");
        double num1= sc.nextDouble();
        System.out.println("Enter num2: ");
        double num2 = sc.nextDouble();

        System.out.println(" choose the option ");
        System.out.println("1.Addition");
        System.out.println("2.subtraction");
        System.out.println("3.multiplication");
        System.out.println("4.subraction");

        System.out.print("select the choice(1-4): ");
        int choice = sc.nextInt();
        double result;
        
        switch(choice) {
            case 1:
                result = num1+num2;
                System.out.println("Result: " +result );
                break;
            case 2:
                result = num1-num2;
                System.out.println("Result: " +result );
                break;
            case 3:
                result = num1*num2;
                System.out.println("Result: " +result );
                break;
            case 4:
                if(num1 != 0){
                    System.out.println(num1%num2);
                }else{
                    System.out.println("cant divide by zer0");
                }
                break;
            default:
                System.out.println("choice is not visible");
            }
        sc.close();
    }
}
    

