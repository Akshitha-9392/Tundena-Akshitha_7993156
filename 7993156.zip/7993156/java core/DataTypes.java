public class DataTypes {

    public static void main(String[] args) {

        int age = 21;

        float height = 5.7f;

        double salary = 45000.75;

        char grade = 'A';

        boolean isStudent = true;

        System.out.println("Age: " + age);

        System.out.println("Height: " + height);

        System.out.println("Salary: " + salary);

        System.out.println("Grade: " + grade);

        System.out.println("Is Student: " + isStudent);

    }
}